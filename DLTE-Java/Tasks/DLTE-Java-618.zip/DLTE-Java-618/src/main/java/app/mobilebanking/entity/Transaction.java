package app.mobilebanking.entity;

public class Transaction {

}
